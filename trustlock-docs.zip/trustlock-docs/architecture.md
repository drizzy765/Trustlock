# TrustLock — Architecture

Same shape as Sell-Safe (FastAPI + Supabase + agent + verifier + deterministic scorer + React dashboard), **new code**, plus a NEAR escrow contract.

```mermaid
flowchart LR
  B[Buyer browser<br/>Wallet Selector] -->|ft_transfer_call / fund_deal_near| C[(Escrow contract<br/>escrow.trustlock-dev.testnet)]
  S[Seller browser] -->|create_deal| C
  B & S -->|evidence, chat export| API[FastAPI backend<br/>Render]
  API --> DB[(Supabase Postgres + Storage)]
  API --> AG[AI agent<br/>NEAR AI Cloud LLM]
  API --> SC[Fraud scorer<br/>core/scoring.py]
  API -->|agent_release / agent_flag<br/>function-call key| C
  API -->|poll RPC| C
  API -->|dry quote| IN[NEAR Intents 1Click API]
  FE[React/Vite<br/>Vercel] --> API
```

## Components
| Component | Tech | Responsibility |
|---|---|---|
| Escrow contract | Rust near-sdk-rs, testnet | Hold funds, state machine, payouts, role checks, agent caps |
| Frontend | React+Vite+TS+Tailwind, `@near-wallet-selector/*`, `near-api-js` | Create/pay/confirm/dispute, verdict display |
| Backend | FastAPI, Python 3.11, `py-near` or JSON-RPC via httpx | Evidence, indexer, agent orchestration, signing agent txs |
| Agent | `core/llm.py` OpenAI-compatible client | Delivery check + dispute summary (JSON output) |
| Scorer | `core/scoring.py` pure Python | Deterministic risk 0-100, explainable rules |
| DB | Supabase Postgres + Storage | Off-chain mirror, evidence files, verdicts |
| Intents | 1Click API (mainnet, `dry:true`) | Cross-chain pay quote |

## Contract
### State
```rust
pub struct Contract {
  owner: AccountId,
  agent: AccountId,            // backend agent account
  arbiter: AccountId,          // human arbiter (Timi for demo)
  allowed_tokens: UnorderedSet<AccountId>, // testnet USDC contract id
  deals: LookupMap<u64, Deal>,
  next_id: u64,
  agent_daily_cap: U128, agent_released_today: U128, agent_day: u64,
}
pub struct Deal {
  id: u64, seller: AccountId, buyer: Option<AccountId>,
  token: Option<AccountId>,     // None = native NEAR
  amount: U128, title: String, ngn_display: Option<u64>,
  status: Status,               // Created|Funded|Released|Refunded|Disputed|Resolved|Cancelled
  created_at: u64, funded_at: Option<u64>, release_after_secs: u64,
  verdict_hash: Option<String>, risk_score: Option<u8>,
}
```
### Methods
| Method | Caller | Rule |
|---|---|---|
| `new(owner, agent, arbiter, usdc)` | init | — |
| `create_deal(title, token, amount, release_after_secs, ngn_display)` → id | seller | status Created |
| `fund_deal_near(deal_id)` #[payable] | buyer | token None, deposit == amount |
| `ft_on_transfer(sender_id, amount, msg)` | USDC contract | predecessor in allowed_tokens, msg `{"deal_id"}`, amount exact else return amount (refund) |
| `confirm_delivery(deal_id)` | buyer | Funded → Released, pay seller |
| `agent_release(deal_id, verdict_hash, risk)` | agent | Funded, risk < 40, under daily cap → Released |
| `agent_flag(deal_id, verdict_hash, risk)` | agent | records verdict, no funds move |
| `open_dispute(deal_id)` | buyer/seller | Funded → Disputed (freezes timeout) |
| `resolve_dispute(deal_id, seller_bps, summary_hash)` | arbiter | split payout |
| `claim_timeout(deal_id)` | seller | Funded and now > funded_at+release_after, not disputed |
| `cancel(deal_id)` | seller | Created only |
| `get_deal`, `list_deals(from,limit)`, `deals_by_account` | view | — |
Payouts use promises + `#[private]` callbacks; on failure revert status. Storage: escrow registers on USDC via `storage_deposit`; seller must be registered on USDC to receive (frontend checks `storage_balance_of`).

## Data model (Supabase)
```sql
deals(id bigint pk /*= chain id*/, seller text, buyer text, token text, amount numeric,
      ngn_display bigint, title text, status text, created_at timestamptz, chain_synced_at timestamptz);
evidence(id uuid pk, deal_id bigint fk, uploader text, kind text /*photo|tracking|chat*/,
         storage_path text, sha256 text, text_content text, created_at timestamptz);
verdicts(id uuid pk, deal_id bigint fk, risk int, decision text /*RELEASE|HOLD|DISPUTE*/,
         red_flags jsonb, summary text, model text, verdict_hash text, tx_hash text, created_at timestamptz);
disputes(id uuid pk, deal_id bigint fk, opened_by text, ai_summary text, resolution_bps int, tx_hash text);
events(id bigserial pk, deal_id bigint, kind text, payload jsonb, created_at timestamptz);
```
`verdict_hash = sha256(canonical JSON of verdict)` — stored on chain for auditability.

## Sequences
### Happy path
```mermaid
sequenceDiagram
  actor S as Seller
  actor B as Buyer
  participant FE as Frontend
  participant C as Escrow
  participant U as USDC (NEP-141)
  participant API as Backend
  participant AI as Agent+Scorer
  S->>FE: New deal ₦25,000 (~15 USDC)
  FE->>C: create_deal
  FE-->>S: pay link /d/7
  B->>FE: open link, connect wallet
  FE->>U: ft_transfer_call(escrow, 15, {"deal_id":7})
  U->>C: ft_on_transfer → Funded
  S->>API: upload waybill + photo
  API->>AI: verify(deal 7)
  AI-->>API: RELEASE risk 12
  API->>C: agent_release(7, hash, 12)
  C->>U: ft_transfer(seller, 15)
```
### Scam / dispute
```mermaid
sequenceDiagram
  participant API as Backend
  participant AI as Agent+Scorer
  participant C as Escrow
  actor A as Arbiter
  API->>AI: verify(deal 8)
  AI-->>API: HOLD risk 85 (reused photo hash, off-platform pay request)
  API->>C: agent_flag(8, hash, 85)
  Note over C: buyer opens dispute
  API->>AI: summarize evidence both sides
  AI-->>A: neutral summary
  A->>C: resolve_dispute(8, seller_bps=0)
  C-->>C: refund buyer
```
### Cross-chain quote
```mermaid
sequenceDiagram
  FE->>API: /quote?from=eth:usdc&amount=15
  API->>1Click: POST /v0/quote {dry:true, destinationAsset: nep141 USDC}
  1Click-->>API: amountIn, fees, ETA
  API-->>FE: "Pay 15.04 USDC from Ethereum"
```

## Security
- Agent key = function-call access key (receiver escrow, methods `agent_release,agent_flag`, small allowance). Never full access. Stored only in Render env.
- Contract caps agent releases/day; agent can only pay the deal's seller.
- Evidence hashed (sha256) to detect reuse; prompt-injection guard: evidence text treated as data, model output must parse into strict JSON schema, else HOLD.
- No secrets in repo; `.env.example` only.

## Deploy
| Piece | Where | How |
|---|---|---|
| Contract | `escrow.trustlock-dev.testnet` | `cargo near deploy build-reproducible-wasm escrow.trustlock-dev.testnet with-init-call new json-args '{...}' ... network-config testnet sign-with-keychain send` (in Codespaces) |
| Backend | Render web service (Docker or `uvicorn app.main:app --host 0.0.0.0 --port $PORT`) | env: SUPABASE_URL, SUPABASE_SERVICE_KEY, LLM_*, NEAR_RPC_URL, ESCROW_CONTRACT, AGENT_ACCOUNT_ID, AGENT_PRIVATE_KEY |
| Frontend | Vercel (Vite) | env: VITE_API_URL, VITE_ESCROW_CONTRACT, VITE_NETWORK=testnet, VITE_USDC_CONTRACT |
| DB | Supabase free | migrations in `backend/migrations/` |
Free Render sleeps — ping `/health` before demo/judging.
