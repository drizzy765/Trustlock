# TrustLock — Implementation Plan (NEAR Hackathon, Nov 1–14 2026)

**One line:** AI escrow for Instagram/WhatsApp/X deals in Nigeria. Buyer pays USDC/NEAR into a NEAR escrow contract; an AI agent checks delivery proof + scam signals; funds release on confirmation or timeout; disputes get an AI evidence summary.

- Tracks (submission ids): `realworld` (main), `security`, `agents`
- Window: code from announcement 2026-10-19 counts; build Nov 1 → **deadline 2026-11-14 23:59 UTC (Nov 15, 00:59 Lagos)**. Judging Nov 16, results by Nov 18.
- Needs: public repo + LICENSE (MIT), README a machine can follow ("do X → see Y"), X demo post tagging @NEARProtocol #NEARHackathon (optional @NearLegion @NearBuilders) with video, **mainnet** NEAR account for payout.
- Screening: Claude Code / Codex clone the repo, run the README, verify features. If README steps fail, score drops. Humans decide.
- Source of truth: https://nearhackathon.com/HACKATHON.md — re-read before submitting.

## Key decisions
| Decision | Choice | Why |
|---|---|---|
| Chain | NEAR **testnet** for escrow | Free, allowed for all tracks (Q-010) |
| Token | Testnet USDC (NEP-141) + native NEAR | Real-World Money = stablecoins |
| Cross-chain | NEAR Intents **1Click API, mainnet, `dry: true` quotes** only | Intents has no testnet (Q-007); show real quotes, no real funds |
| Contract | Rust, `near-sdk-rs` + `cargo-near` (build in GitHub Codespaces/Actions — laptop is weak) | Most mature SDK, best examples |
| AI | NEAR AI Cloud (OpenAI-compatible, `https://cloud-api.near.ai/v1`) — private inference fits the evidence-privacy story; Gemini/Groq fallback via env | Track hint fit; $10 credits via nearbuilders.org/join |
| Backend | FastAPI + Supabase Postgres (Sell-Safe architecture, **new code**) | Known stack |
| Frontend | React + Vite + Tailwind + NEAR Wallet Selector | Known stack |
| Hosting | Contract testnet, backend Render, frontend Vercel | Free tiers |

## Day-by-day
### Day 1 — Sun Nov 1: Repo + wallets
- Create fresh public-able repo `trustlock`, MIT LICENSE, README skeleton, `.gitignore` (`.env`, `node_modules`, `target/`, `__pycache__`), `.env.example`.
- Install near-cli-rs; create `trustlock-dev.testnet`, `buyer-tl.testnet`, `seller-tl.testnet`, `agent-tl.testnet` (see near.md).
- Commit docs (this file, architecture.md, agent.md, near.md).
- **Accept:** `near account view-account-summary trustlock-dev.testnet network-config testnet now` shows balance; first commit pushed.

### Day 2 — Nov 2: Contract skeleton
- `cargo near new contract`; state + `create_deal`, `get_deal`, `list_deals_by_party`. Unit tests.
- **Accept:** `cargo test` green in Codespaces; contract deployed to `escrow.trustlock-dev.testnet`; `get_deal` view works from CLI.

### Day 3 — Nov 3: Funding (NEAR + USDC)
- Native NEAR: `fund_deal_near` (#[payable]). USDC: `ft_on_transfer` (buyer calls `ft_transfer_call` on USDC contract with `msg = {"deal_id":N}`); reject wrong token/amount (return refund).
- Get testnet USDC (Circle faucet, see near.md); register storage for escrow on USDC contract.
- **Accept:** CLI test: buyer funds deal 1 with 1 USDC → state `Funded`; wrong amount gets refunded.

### Day 4 — Nov 4: Release / refund / timeout / dispute
- `confirm_delivery` (buyer), `agent_release` (agent, only if verdict approves), `claim_timeout` (seller after `release_after`), `open_dispute`, `resolve_dispute` (arbiter), `cancel` (before funding). Payouts via `ft_transfer` / `Promise::transfer` with callbacks that revert state on failure.
- Integration tests with `near-workspaces`.
- **Accept:** all state transitions tested; no double payout test passes.

### Day 5 — Nov 5: Backend core
- FastAPI: `/health`, `/deals` CRUD (mirror of chain), `/deals/{id}/evidence` upload (Supabase Storage), indexer job polling RPC for contract state.
- Supabase tables (architecture.md). 
- **Accept:** `pytest` green; `uvicorn` local; a deal created on chain (signed by the seller via CLI/wallet) appears in the DB within 30 s via the indexer; the backend never signs deal creation.

### Day 6 — Nov 6: Fraud scorer (deterministic)
- `core/scoring.py`: rules → 0-100 risk: new account age, amount vs. listing price, duplicate evidence hash, tracking number format/unknown courier, mismatched names, urgency/off-platform-payment phrases (Pidgin + English list), seller dispute history.
- **Accept:** 15+ unit test fixtures (legit, fake receipt, reused photo, "pay to my personal account") with expected bands.

### Day 7 — Nov 7: AI agent
- `core/llm.py` env-switchable (`LLM_BASE_URL`, `LLM_API_KEY`, `LLM_MODEL`); default NEAR AI Cloud.
- Agent: reads chat export text + photo (vision model or caption) + tracking → JSON `{delivered: bool, confidence, red_flags[], summary}`; combine with scorer → verdict `RELEASE | HOLD | DISPUTE`.
- Rules-only fallback when no key.
- **Accept:** `/deals/{id}/verify` returns verdict JSON for 3 fixture cases in < 20 s.

### Day 8 — Nov 8: Agent on chain (security story)
- Agent account holds a **function-call access key** limited to the escrow contract and methods `agent_release`, `agent_flag` (no transfer power). Contract enforces: agent can only release to the seller of that deal, only when Funded, and only up to deal amount. Per-day agent release cap in contract.
- Store verdict hash on chain (`agent_flag` / `agent_release` take `verdict_hash`).
- **Accept:** agent key cannot call `resolve_dispute` or transfer (show failing tx in demo).

### Day 9 — Nov 9: Dispute summary + Intents quote
- Dispute: agent produces neutral evidence summary (both sides, timeline, flags) saved + hash on chain.
- Intents: `/quote` calls 1Click `POST https://1click.chaindefuser.com/v0/quote` with `dry: true` (e.g. USDT on Tron/ETH USDC → NEAR USDC), shown on checkout as "pay from any chain". No real mainnet funds unless tiny & deliberate.
- **Accept:** dispute page shows summary; checkout shows a live dry quote.

### Day 10 — Nov 10: Frontend I
- Vite app: Wallet Selector (MyNearWallet / Meteor / HOT), pages: Create deal (seller), Pay link `/d/:id` (buyer), Deal timeline.
- **Accept:** full happy path in browser on testnet.

### Day 11 — Nov 11: Frontend II
- Evidence upload, AI verdict card (risk score, red flags), dispute view, seller dashboard. Naira display (₦ via a cached FX rate, labelled indicative).
- **Accept:** all 4 demo scenarios clickable.

### Day 12 — Nov 12: Deploy + README
- Backend → Render, frontend → Vercel, env vars set in dashboards only. Seed script for demo deals.
- README final (agent.md section "README requirements"). Fresh-clone test: follow README on a clean Codespace.
- **Accept:** fresh clone runs by README alone; hosted demo URL works.

### Day 13 — Nov 13: Demo video + X post
- Record, edit (≤ 2:30), draft post (below). Timi posts himself.
- **Accept:** post URL live, video attached.

### Day 14 — Nov 14: Submit (morning Lagos, not 23:59)
- Run checklist; Timi confirms payload; submit via form or API. Tag `hackathon-submission`.

**Buffer rule:** if behind by Day 9, cut Intents to a "quote" button only and drop dashboard charts. Never cut: contract, scorer, agent verdict, README.

## Demo video (≤ 2:30)
1. 0:00 Problem: "In Lagos, IG buyers are scared to pay first; sellers are scared to ship first." (1 line + fake-alert screenshot)
2. 0:15 Seller creates ₦25,000 deal → link.
3. 0:35 Buyer opens link, sees Intents quote "pay from any chain", pays 15 USDC testnet → contract `Funded` (explorer link).
4. 1:00 Seller uploads waybill + photo; agent verdict RELEASE, score 12 → funds released (tx shown).
5. 1:25 Scam case: reused photo + "send to my personal account" → HOLD, risk 85.
6. 1:50 Dispute: AI evidence summary; arbiter resolves.
7. 2:10 Security: agent key cannot move funds except `agent_release` within cap.
8. 2:20 Repo + demo links.

## X post draft (Timi posts)
> Buying on Instagram in Nigeria = trust fall. Buyer won't pay first, seller won't ship first.
> Built TrustLock at NEAR HACKATHON: buyer's USDC sits in a NEAR escrow contract, an AI agent checks delivery proof + scam signals, then releases. Agent can only release — never withdraw.
> Demo ▶️ [video] · Repo: [link] · Try: [link]
> Which scam should it catch next?
> @NEARProtocol #NEARHackathon @NearBuilders @NearLegion

## Submission checklist
- [ ] Repo public, MIT LICENSE, no secrets (`git log -p | grep -i key` clean, `.env` never committed)
- [ ] README: what/problem/how to try (do X → see Y), setup on fresh clone, contract address, tracks, libraries used, disclosure of pre-hackathon baseline (none — fresh repo; Sell-Safe is a separate project and named per Q-015 if also submitted)
- [ ] Contract deployed testnet, address in README; tests pass (`cargo test`, `pytest`)
- [ ] Hosted demo up through Nov 25
- [ ] X post live with video, tags
- [ ] Mainnet payout account (Timi creates it himself, e.g. `timi.near`)
- [ ] Payload fields: projectName, leadName, email, size `1`, tracks `["realworld","security","agents"]`, nearAddress, projectUrl, demoUrl, idea (≤2000 chars), consent — **Timi confirms before sending; one attempt only**
- [ ] Tag `hackathon-submission`

## Future work (not in scope)
- Sell-Safe checkout integration: Sell-Safe vendors offer "Pay with TrustLock" escrow at checkout.
- WhatsApp bot intake, Chain Signatures payouts to other chains, Naira off-ramp, reputation NFTs.
